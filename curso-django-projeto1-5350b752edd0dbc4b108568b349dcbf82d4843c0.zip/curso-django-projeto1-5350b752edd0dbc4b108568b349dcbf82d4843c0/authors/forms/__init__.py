# flake8: noqa
from .login import LoginForm
from .register_form import RegisterForm
